<?php namespace Laracasts\Presenter\Exceptions;

class PresenterException extends \Exception {}
<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('home');
});

Route::get('/forms', function(){
    return view('form');
});

Route::get('/table', function () {
    return view('table');
});

Route::get('/calendar', function () {
    return view('calendar');
});
Route::get('/ui', function () {
    return view('ui');
});
Route::get('/icon', function () {
    return view('icon');
});
Route::get('/charts', function () {
    return view('charts');
});
Route::get('/videoplayer', function () {
    return view('videoplayer');
});
Route::get('/error', function () {
    return view('error');
});
Route::get('/invoice', function () {
    return view('invoice');
});

Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');

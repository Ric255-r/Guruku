

<?php $__env->startSection('content'); ?>
    <div class="main-container">
		<div class="pt-5 mt-5">
			<div class="error-page-wrap text-center">
				<h1>400</h1>
				<h3>Error: 400 PAGE NOT FOUND !</h3>
				<p>You Seem To Be Trying To Find His Way Home</p>
				<div class="pt-20 mx-auto max-width-200">
					<a href="index.html" class="btn btn-primary btn-block btn-lg">Back To Home</a>
				</div>
			</div>
		</div>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\tugaslaravel\TemplateAdmin\resources\views/error.blade.php ENDPATH**/ ?>
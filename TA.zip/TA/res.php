<!DOCTYPE html>
<html>
<head>
	<title></title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<style>
		body{

		}
@media (max-width: 450px) {  
	body{background:red;}
}
@media(min-width: 540px) { 
	body{background:blue;} 
}
@media(min-width: 768px) { 
	body{background:green;}
}
@media(min-width: 1024px) { 
	body{background:yellow;} 
}
@media(min-width: 1200px) { 
	body{background:black;} 
}
	</style>
</head>
<body>
<h1>lol</h1>
</body>
</html>
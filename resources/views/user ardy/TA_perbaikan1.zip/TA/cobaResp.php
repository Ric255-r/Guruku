<!DOCTYPE html>
<html>
<head>
	<title></title>
<link rel="stylesheet" href="css/bootstrap.css">
<style type="text/css">

/*Extra small devices (portrait phones, less than 576px)*/
@media (max-width: 575.98px) { 
		.kotak{
			background-color: blue
		}
}

// Small devices (landscape phones, 576px and up)
@media (min-width: 576px) and (max-width: 767.98px) { 
	.kotak{
		font-size: 300px;
	}
}

// Medium devices (tablets, 768px and up)
@media (min-width: 768px) and (max-width: 991.98px) { 

 }

// Large devices (desktops, 992px and up)
@media /*(min-width: 992px)*/only screen and (max-width: 900.98px) { 
		.kotak{
			background-color:blue;
		}
 }

// Extra large devices (large desktops, 1200px and up)
@media (min-width: 1200px) { 
		.kotak{
			background-color:blue;
		}
 }


.kotak{
	background-color: red;
}
</style>
</head>
<body>
<div class="kotak">haiii</div>
</body>
</html>